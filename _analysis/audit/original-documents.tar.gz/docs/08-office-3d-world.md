# The Office — 3D World Specification

264 Swift types, a custom Metal renderer, VRM avatars, an OpenStreetMap-derived San Francisco
environment, spatial audio, and LiveKit voice. This is Matrix's signature surface and the
single hardest component to reproduce.

---

## 1. What it is

A real-time 3D office you can inhabit. Each **department is a room**; each **worker is an
animated character** at a workstation whose monitor shows its live terminal/transcript output;
department artifacts appear as folders you can open; skills sit on a shelf; whiteboards are
editable; and the building stands in a low-poly San Francisco with the Transamerica Pyramid,
street trees, bay traffic and a day/night sky.

```mermaid
flowchart TB
    subgraph scene["OfficeSceneRuntime"]
        SM["OfficeSceneModel<br/>scene graph + sync state"]
        CAT["OfficeSceneAssetCatalog"]
        ENV["OfficeSceneEnvironmentProfile<br/>+ OfficeEnvironmentTimeState"]
        THEME["OfficeSceneTheme"]
    end
    subgraph render["OfficeMetalRenderer"]
        PIPE["Pipeline bundles:<br/>mesh · VRM · primitive · depth · sampler · shader lib"]
        CULL["OfficeCullingFrustum"]
        LOD["OfficeAdaptiveSceneLoadProfile<br/>+ RuntimePressureEvaluation"]
        FX["MetalFX upscaler · TAA · SSAO · bloom · exposure · reflections"]
    end
    subgraph content["Scene content"]
        CITY["San Francisco OSM environment"]
        FURN["Workstations · chairs · sofas · plants · folders · skill shelf"]
        AV["VRM avatars (workers)"]
        PANEL["Worker screens · presentation panels · department signs · wall photos"]
    end
    subgraph interact["Interaction"]
        CAM["Camera modes · first person · cinematic"]
        INT["OfficeInteractionTarget/Prompt/DetailOverlay"]
        LIVE["Live panel · voice HUD · visitors"]
        PHOTO["Photo mode · gallery"]
    end
    scene --> render --> content
    interact --> scene
```

---

## 2. Renderer

### 2.1 Metal shader entry points (`default.metallib`)

```
office_vertex / office_fragment                  base geometry
office_mesh_vertex / office_mesh_fragment        GLB/USDZ meshes
office_mesh_shadow_vertex                        shadow pass (meshes)
office_vrm_vertex / office_vrm_shadow_vertex     skinned VRM characters
office_shadow_vertex                             shadow pass (primitives)
office_fullscreen_vertex / _far_vertex           fullscreen passes
office_environment_background_fragment           environment/sky background
office_baked_sky_fragment                        baked sky
office_ssao_fragment                             screen-space ambient occlusion
office_taa_fragment                              temporal anti-aliasing
office_bloom_extract_fragment / _kernel          bloom extraction
office_blur_fragment / _kernel                   separable blur
office_composite_fragment                        final composite
office_exposure_kernel                           auto-exposure
office_reflection_resolve_kernel                 reflections
office_reactive_mask_kernel                      reactive mask (for TAA/upscale)
city_terrain_vertex / _fragment                  city ground
farm_terrain_vertex / _fragment                  "farm" environment ground
farm_grass_vertex / _fragment                    instanced grass
```

Uniform/binding names extracted from the library confirm a modern PBR deferred-ish pipeline:
`baseColorMap`, `emissiveMap`, `aoMap`, `brdfTexture`, `environmentTexture`, `anisotropy`,
`bloomParams`, `blurParams`, `cinematicParams`, `atmosphereParams`, `fogParams`,
`currentViewProjectionMatrix` (TAA reprojection), `departmentCarpetTexture`,
`focusedWorkerScreenTexture`, `focusedPanelTexture`.

Two of those are the interesting ones: **`focusedWorkerScreenTexture`** and
**`focusedPanelTexture`** — live app content rendered into the 3D scene as textures.

### 2.2 Quality & adaptivity

```
OfficeRenderQualityProfile / OfficeRenderQualityTier
OfficeAdaptiveSceneLoadProfile      → adaptiveLoadLevel: Int fed into environment generation
OfficeMetalRendererGPUPressure
OfficeMetalRendererRuntimePressureEvaluation
OfficeMetalFXMode / OfficeMetalFXUpscaler        (MetalFX spatial/temporal upscaling)
OfficeSkyQuality / OfficeSkyTimePreset
OfficeRenderDiagnosticsSnapshot / OfficeRenderPassTimingSummary / OfficeRendererDiagnosticsHUD
OfficeRendererWarmupStage / OfficeMetalRendererPreparedStartupResources
OfficeStartupStallProbe
```

The renderer measures GPU pressure and *degrades the scene*, not just the resolution: the
`adaptiveLoadLevel` parameter is threaded into
`appendSanFranciscoOSMCoreEnvironment(...)` and controls how much city gets built.

Caching is aggressive and keyed:
`OfficeStaticSceneCacheKey`, `OfficeRetainedStaticEnvironmentCache`,
`OfficeSanFranciscoCityResourceCache` (+ `CityResourceCacheKey`, `CityResourceBuildRequest`),
`OfficeDepartmentSignCacheKey/Entry`, `OfficePixelTextMaskCacheKey`,
`OfficeVacantWorkstationCacheKey/SlotKey/AgentKey`,
`OfficePresentationPanelTextureSignature/Detail`, `OfficeWorkerScreenTextureSignature/Detail`.

Texture *signatures* are the key idea: a worker's monitor texture is only re-rendered when the
signature of its content changes, not per frame.

---

## 3. Environment

### 3.1 San Francisco from OpenStreetMap

`sf_downtown_osm_environment.json` (924 KB) → `OfficeSanFranciscoOSMEnvironment.Dataset` →
`appendSanFranciscoOSMCoreEnvironment(...)`, whose signature (recovered from the demangled
symbol) is a complete description of the generator:

```swift
appendSanFranciscoOSMCoreEnvironment(
  _ dataset: OfficeSanFranciscoOSMEnvironment.Dataset,
  center: SIMD3<Float>, cityGridYaw: Float, streetLevelY: Float,
  cityRadius: Float, outerCityRadius: Float,
  towerReserveX: Float, towerReserveZ: Float,
  environmentScale: Float, detailScale: Float,
  isLightAppearance: Bool, adaptiveLoadLevel: Int,
  cityGroundMaterial: (color: SIMD4<Float>, emissive: SIMD4<Float>,
                       roughness: Float, metallic: Float, alpha: Float),
  buildingPalette: [SIMD4<Float>], windowGlow: SIMD4<Float>,
  fogMixTarget: SIMD4<Float>, fogGeometryScale: Float,
  intoOpaque: inout [OfficeGPUInstance],
  intoOpaqueCylinder: inout [OfficeGPUInstance],
  includesCityBuildings: Bool,
  intoTransamericaPyramidPlacements: inout [...],
  intoCityTreePlacements: inout [...]) -> ()
```

Plus `appendSanFranciscoWaterfront(...)` with `buildingWaterOccupancyScore`,
`shorelineWaterScore` closures and a `MarinePlacement` generator for **bay marine traffic**.
Cached filters (`CachedShorelineBandFilter`, `CachedWaterBodyFilter`) memoize the expensive
geometric queries.

### 3.2 Assets

| Asset | Use |
|---|---|
| `Transamerica Pyramid.usdz` (2.2 MB) | landmark |
| `City_pack_3.usdz` (22.7 MB) | city buildings |
| `City_Low_Poly_Street_Trees.usdz` | street trees |
| `Parametric_Workstation_Desk.glb`, `Parametric_Office_Chair.glb`, `Office_Chair.usdz` | workstations |
| `Conference_Table_Rectangular_6m.usdz` | boardroom |
| `Outdoors_Sofa.usdz` (5.1 MB) | lounge |
| `Indoor_Plant_02_Fbx.usdz`, `Rhyzome_Plant.usdz`, `bush.glb`, `succulent.glb`, `blue-tree.glb`, `silver-tree.glb` | greenery (`PlantVariant/Anchor/Placement`) |
| `folder-single.glb` | department artifact folders |
| `skill-shelf.glb` | skills as physical books |
| `ice-cluster.glb`, `tall-prism.glb` | decor |
| `Knight.glb`, `Mage.glb` | built-in characters |
| `claude.gltf`, `codex.gltf` | runtime-branded avatars |
| `qwantani_dusk_2_puresky_2k.hdr` (4.6 MB) | IBL environment map |
| `office_post_processing.json` | post-FX config |

Loading: `OfficeEmbeddedGLTFAssetLoader`, `OfficeAssetPipeline` (with texture expansion to
RGBA and alpha-preserving recolor), `OfficeMeshAsset`, `OfficeLoadedScene/MeshNode`,
`OfficeSubmeshMaterial`, `OfficeMaterialAlphaMode`.

### 3.3 Time, weather, audio

```
OfficeEnvironmentTimeState · OfficeSkyTimePreset
OfficeEnvironmentAudioController / Emitter / SceneState / Settings
OfficeEnvironmentAudioActivitySignature     ← ambience reacts to real agent activity
```

The ambience is driven by an **activity signature** — a busy company literally sounds busier.

---

## 4. Characters

### 4.1 VRM pipeline (custom, from scratch)

```
OfficeVRMDocument · OfficeVRMDocumentParser · OfficeVRMParsedFile · OfficeVRMParseError
OfficeVRMHumanoidBone · OfficeVRMHumanoidMap · OfficeVRMCharacterSkeleton
OfficeVRMJointMatrixRange          (GPU skinning ranges)
OfficeVRMPrimitiveAsset · OfficeVRMPrimitiveMorphPlan · OfficeVRMMorphTargetAsset
OfficeVRMExpressionSet             (blendshape expressions)
OfficeVRMCharacterAsset · OfficeVRMCharacterRuntime · OfficeVRMCharacterPlacement
OfficeVRMAvatarCatalogItem/MemoryCache/Error · OfficeVRMAvatarSelection
OfficeAnimationClip
```

VRM 1.0 humanoid avatars with morph targets and expressions, parsed natively (no third-party
runtime) and skinned in `office_vrm_vertex`. Users pick avatars via `OfficeAvatarPickerPanel` /
`OfficeAvatarCatalogTile`.

Built-ins: `OfficeBuiltinCharacterCard`, `OfficeBuiltinWorkerCharacter`,
`OfficeWorkerCharacterModelKind`, `OfficeWorkerCharacterMaterialRole`,
`OfficeMetalRendererWorkerCharacterPalette`, `OfficeWorkerVariationProfile` — so multiple
workers of the same model are visually distinguishable.

### 4.2 Behaviour

```
OfficeWorkerSceneState / SceneAction / SceneActionKind / ResolvedWorkerActionKind
OfficeWorkerNavigation / ResolvedNavigation / Waypoint / TravelMode / SeatMode
OfficeWorkerAnchor · OfficeResolvedAnchor
OfficeWorkerConversation / ConversationFocus / ConversationSnapshot
OfficeBoardroomMeetingState
OfficeLeadAgentSceneState / SceneAction / SceneSource
OfficeAvatarReactionKind / Request / Sound / ClickState
OfficeFirstPersonState / CollisionBlocker / PoolArea
```

Agents **walk** (navigation with waypoints and travel modes), **sit** (seat modes, vacant
workstation allocation), **talk to each other** (conversations with focus), and **hold
boardroom meetings**. Department messages become visible traffic: `DepartmentMessageFlightIcon`,
`DepartmentMessageSidebarFlight`, `DepartmentMessageTransferPulse/Direction`.

Clicking an avatar triggers a reaction with a sound. There is a **pool area**. This is a game,
and it is deliberate.

---

## 5. Live app content inside the scene

| In-world object | Backing content |
|---|---|
| Worker monitor | `OfficeWorkerScreenTextureSignature/Detail` → live transcript/TUI output |
| Presentation panel | `OfficePresentationPanelTextureSignature/Detail`, `OfficePresentationTranscriptCacheEntry` |
| Department sign | `OfficeDepartmentSignCacheKey/Entry`, `OfficeDepartmentCornerSignTextLine/Role` |
| Department folders | `OfficeMetalRendererFolderPlacement`, `OfficeDepartmentFolderMaterialKind`, `OfficeDepartmentArtifactsSpatialOverlay` |
| Skill gallery | `OfficeMetalRendererSkillGalleryPlacement` |
| Whiteboard | `OfficeWhiteboardEditorView` → tldraw WebView |
| Wall photos | `OfficeWallPhotoService`, `OfficeWallPhotoSceneEditorView`, `ProjectedWallPhotoFrame`, resize handles, hit surfaces |
| Pixel text | `OfficePixelTextMaskFontStyle` (low-res in-world labels) |

`OfficeDepartmentArtifactsOverlayProjection` + `OfficeProjectedPoint` project 3D world positions
into 2D SwiftUI overlay space — that is how a 3D folder opens a real SwiftUI file panel.

---

## 6. Camera & modes

```
OfficeCameraMode / CameraModeCluster / CameraModeSegmentButton
OfficeMetalCameraController · OfficeCinematicCameraProfile
OfficeFirstPersonModeButton / OfficeFirstPersonState
Office3DPresentationMode · OfficePresentationModeLifecycle
OfficeImmersiveModeButton / ImmersiveExitButton / ImmersiveWindowFrameController
OfficeInteractiveMTKView · OfficeMetalView · OfficeOverlayView · OfficeContainerView
```

Modes: orbit/overview, **first person** (with collision blockers), cinematic,
presentation, immersive (frameless window).

### 6.1 Photo mode

A complete in-app camera: `OfficePhotoModeState/Overlay`, `OfficePhotoViewfinder`,
`OfficePhotoAimingOverlay`, `OfficePhotoControlButton/Indicator`,
`OfficePhotoGenerationControlBar`, `OfficePhotoRenderService/RenderResult`,
`OfficePhotoGalleryOverlay/Item/Thumbnail/Preview`, plus generating/failed/loading overlays.
Captured frames (`OfficeCapturedFrame`) can be **AI-processed** (the generation control bar +
`OfficePhotoProcessingBackdrop`) and hung on the office walls.

---

## 7. Live sessions & voice

```
OfficeLiveButton · OfficeLivePanelView · OfficeLiveParticipantRow · OfficeLiveStatusPill
OfficeLivePlayDeck / PlayAction / PlayActionLabel / InteractionKind
OfficeLiveVisitorSceneBanner / SceneContext · OfficeVisitorSnapshot
OfficeVoiceSceneHUD · OfficeVoiceHUDButton · OfficeVoiceSceneSignature
OfficeLocalLiveInteraction · OfficeLocalInteractionKind
```

Backed by `LiveKitWebRTC.framework` + `RustLiveKitUniFFI.framework` (LiveKit Swift SDK with a
Rust core over UniFFI) and `ElevenLabs.bundle`.

Voice stack:

```
MATRIX_VOICE_PROVIDER = "elevenlabs"
MATRIX_ELEVENLABS_AGENT_ID / _ENVIRONMENT   (Info.plist, blank in this build)
ElevenLabsVoiceClient · RealtimeVoiceClient · VoiceCallSession · VoiceCallPhase
SpeechRecognitionService · TextToSpeechService · SpeechSynthDelegateHandler
ComposerSpeechToTextSession · ComposerVoiceLiquidOrb
```

So: **multiplayer visitors can join your office over LiveKit, and you can hold a voice
conversation with a department while standing in its room.** `HubService.broadcastFocus` /
`broadcastActivity` and the `presence.update` / `focus.broadcast` / `activity.broadcast`
endpoints carry presence.

---

## 8. Scene ↔ state synchronization

```mermaid
sequenceDiagram
    participant D as Daemon events
    participant M as OfficeSceneModel
    participant R as OfficeMetalRenderer
    participant O as SwiftUI overlays
    D->>M: department.status / task.tool.start / chat.delta / hook progress
    M->>M: compute OfficeSceneUpdateSignature
    alt signature changed
        M->>R: enqueue placement + texture updates
        R->>R: rebuild only affected caches
    else unchanged
        M->>M: skip (no GPU work)
    end
    R-->>O: OfficeProjectedPoint for anchors
    O-->>O: place interaction prompts / artifact overlays in 2D
```

`OfficeSceneSyncState`, `OfficeSceneUpdateSignature`, and the `OfficeContainer*Events` families
(`ApplicationActivity`, `Lifecycle`, `Live`, `MountLifecycle`, `Renderer`, `Scene`) form a
narrow, explicit bridge between app state and scene state.

---

## 9. Cost of reproduction

| Layer | Effort | Substitutable? |
|---|---|---|
| VRM parser + GPU skinning | very high | **Yes** — use an off-the-shelf engine (three.js/R3F, Godot, RealityKit) |
| Metal renderer + post-FX | very high | **Yes** — engine gives you this |
| OSM city generation | high | **Yes** — a stylised abstract set is better for a *studio* anyway |
| Room/desk/anchor allocation | medium | No — this is the actual product logic |
| Worker behaviour state machine | medium | No — this is the product logic |
| Live content-as-texture | medium | No — this is the magic |
| Scene update signatures | low | No — but trivial to reimplement |

**Recommendation for shotgun-next:** do not write a renderer. Build the studio floor in
React-Three-Fiber (web) or RealityKit/SceneKit (native) and spend all the effort on the
*behaviour* layer — anchors, navigation, conversations, live screens, and the signature-based
update gate. Those are what make it feel alive; the triangles are commodity.
