# Build, Packaging & Distribution

How Matrix is assembled and shipped — and exactly how this teardown was produced.

---

## 1. Bundle layout

```
Matrix.app/                                             894 MB
└── Contents/
    ├── Info.plist                  com.matrixai.app · 1.0.6 (148) · matrix:// · macOS 14.6+
    ├── MacOS/Matrix                166 MB  Mach-O arm64 (Swift 6, Xcode 17F113, SDK macosx26.5)
    ├── Frameworks/
    │   ├── LiveKitWebRTC.framework        28.7 MB
    │   ├── RustLiveKitUniFFI.framework
    │   └── Sparkle.framework
    ├── Resources/
    │   ├── neo-agent               65 MB   Bun single-file executable
    │   ├── neo-intelligence        78 MB   Bun single-file executable
    │   ├── matrix-browser/
    │   │   ├── matrix-browser-server   61 MB  Bun exe (loads main.js)
    │   │   ├── matrix-browser-mcp      545 KB Rust supervisor
    │   │   ├── main.js                 4.3 MB Playwright-based server
    │   │   ├── node_modules/{playwright,playwright-core,chromium-bidi}
    │   │   └── cloakbrowser/Matrix Browser.app   Chromium 145.0.7632.109
    │   ├── neo-agent-seed/         prompts · templates · integration-packs · scripts
    │   ├── GhosttyRuntime/         ghostty + terminfo + shell-integration + themes
    │   ├── vendor/ripgrep/arm64-darwin/rg
    │   ├── *.bundle                SPM resource bundles (13)
    │   ├── *.lproj                 12 locales
    │   ├── 3D assets               *.glb *.usdz *.hdr *.gltf
    │   ├── default.metallib        compiled Metal shaders
    │   ├── Assets.car              21.5 MB
    │   ├── ~500 terminal themes    (Ghostty theme files, 475 B each)
    │   ├── version.json · runtime-versions.json · office_post_processing.json
    │   ├── sf_downtown_osm_environment.json   924 KB
    │   ├── codemirror-preview.js   707 KB
    │   ├── brand.mp4 · fonts (ABCLaica, InstrumentSerif)
    │   └── .zshenv · bash-preexec.sh · ghostty.bash
    └── _CodeSignature/
```

### 1.1 SPM resource bundles

`TranscriptWebView`, `MarkdownView`, `WhiteboardWebView`, `Highlightr`, `Kingfisher`,
`SwiftTerm`, `LiveKit`, `SwiftProtobuf`, `swift-crypto`, `ElevenLabs` — the app is assembled
from Swift packages, several of which ship web bundles built by Vite (`assets/*-<hash>.js`,
`bundle-version.txt`).

---

## 2. Version manifests

`Resources/version.json`:

```json
{ "version":"1.0.6", "build":"148", "channelLabel":"",
  "builtAt":"2026-08-20T13:35:56Z",
  "components":{
    "neo-agent":       {"version":"0.1.60","sha":"76894dbbb"},
    "neo-intelligence":{"version":"0.1.60","sha":"76894dbbb"},
    "matrix-browser":  {"version":"0.1.0","sha":"76894dbbb"} } }
```

`Resources/runtime-versions.json` — the external-runtime manifest used by the installer
(url + sha256 + binary subpath + `needsAdhocResign`). See
[runtime spec §6](02-runtime-architecture.md#6-agent-runtime-abstraction).

The three first-party components share one git SHA — they are built from a monorepo. Paths
recovered from the bundles confirm it:

```
apps/harness/src/daemon/runtime-prompt-context.ts
apps/harness/seed/prompts/workspace-schema.md
../hq/mac/build/resources/neo-intelligence-bundle.js
src/main.rs                                (matrix-browser-mcp)
```

So the repo is roughly `apps/harness` (neo-agent), the neo-intelligence bundle, `hq/mac`
(the Swift app), and a Rust crate — with the Swift build step vendoring the JS artifacts.

---

## 3. Compilation targets

| Component | Toolchain | Notes |
|---|---|---|
| Matrix | Swift 6 / Xcode 2660 (17F113), SDK macosx26.5, target arm64 | Hardened Runtime; `NSQuitAlwaysKeepsWindows` |
| neo-agent / neo-intelligence / matrix-browser-server | **Bun** `--compile` | `__BUN` Mach-O section, JavaScriptCore (`__jsc_int`, `__jsc_opcodes`, `__wtf_config`) |
| matrix-browser-mcp | Rust (rustc `8bab26f4f…`) | `src/main.rs`, panics with `matrix-browser-supervisor:` prefix |
| Metal shaders | `metal` → `default.metallib` | 28 entry points |
| Web bundles | Vite | transcript / whiteboard / codemirror |

**Bun `--compile` is the right call for a component like this**: single file, no Node install,
fast start, and the JS is still recoverable (as this teardown shows — do not treat it as
obfuscation).

---

## 4. Distribution

```
Sparkle appcast   https://download.matrix.build/mac/appcast.xml
Release notes     https://download.matrix.build/mac/history.html
Signature         EdDSA, SUPublicEDKey i9KwWamgG5pgI3A3oOsYttjDPlC7G+7JEeDpKvbAFxg=
Check interval    86400 s, automatic
```

Two independent update channels:

1. **App** — Sparkle, signed, whole bundle.
2. **Agent runtimes** — downloaded on demand from npm/GitHub, SHA-256 verified, installed to
   `~/.neo/runtimes/<kind>/current`, ad-hoc re-signed where needed.

Channel 2 means Claude Code and Codex can be updated without shipping a new app.

---

## 5. Reproducing this teardown

All commands are read-only apart from the initial copy.

```bash
# 0 — work on a copy
mkdir -p ~/work/matrix && cp -R /Applications/Matrix.app ~/work/matrix/
cd ~/work/matrix/Matrix.app/Contents

# 1 — identify the binaries
file MacOS/Matrix Resources/neo-agent Resources/neo-intelligence
otool -l Resources/neo-agent | grep -A5 'sectname __bun'      # → offset, size

# 2 — extract the Bun bundles (offset/size from step 1)
dd if=Resources/neo-agent        of=neo-agent.bun        bs=1 skip=60358656 count=$((0x497fed))
dd if=Resources/neo-intelligence of=neo-intelligence.bun bs=1 skip=60358656 count=$((0x10d0815))

# 3 — carve out the JS (starts at the shebang, runs to the module table)
python3 - <<'PY'
for n in ("neo-agent","neo-intelligence"):
    b=open(f"{n}.bun","rb").read(); i=b.find(b"#!/usr/bin/env bun")
    open(f"{n}.js","w").write(b[i:].decode("utf-8","replace"))
PY

# 4 — beautify (deno works offline; prettier also fine)
deno fmt --no-config --line-width 100 neo-agent.js        #  12k → 153k lines
deno fmt --no-config --line-width 100 neo-intelligence.js # 322k → 616k lines

# 5 — recover the module map (Bun preserves original module names)
grep -oE 'var init_[A-Za-z0-9_]+ = __esm' neo-agent.js | sed 's/var init_//;s/ = __esm//' | nl

# 6 — recover the Swift type graph
nm MacOS/Matrix | awk '{print $NF}' | grep -E '^_?\$s6Matrix.*Mn$' | sort -u > types.mangled
xcrun swift-demangle --compact < types.mangled | sort -u > types.demangled
#   the "(Name in _HEXHASH)" discriminator groups types by SOURCE FILE

# 7 — shaders, strings, assets
strings -a Resources/default.metallib | grep -E '_(vertex|fragment|kernel)$' | sort -u
plutil -convert json -o - Resources/en.lproj/Localizable.strings
plutil -p Info.plist ; codesign -d --entitlements - --xml /Applications/Matrix.app

# 8 — the daemon's own self-description
Resources/neo-agent info      # prints the full contract JSON
Resources/neo-agent           # prints the CLI surface
```

Live runtime state (read-only, on a machine that has run the app):

```bash
cat ~/.neo/config.json
find ~/.neo/workspaces -maxdepth 2
sqlite3 ~/.neo/workspaces/<ws>/department-messages/messages.sqlite .schema
cat ~/.neo/daemon/status.json
defaults read com.matrixai.app | head -40
```

### 5.1 Notes / gotchas

- `swift-demangle` is at `/Library/Developer/CommandLineTools/usr/bin/swift-demangle`; reach it
  with `xcrun swift-demangle`, it is not on `PATH`.
- `neo-intelligence` is minified (mangled identifiers) but all **strings, prompts, tool
  descriptions and schemas are intact** — grep for prose, not for symbols.
- `neo-agent` is **not** minified: function names, module names, comments in template literals
  and full prompt text survive. This is where 90 % of the architecture lives.
- The `(Name in _HEXHASH)` private discriminator in Swift symbols is a per-file hash — grouping
  by it reconstructs the source file layout (279 files here).
- `timeout` is not available on stock macOS zsh; use a different bound if you script long runs.

---

## 6. Rough build order for a clone

```mermaid
flowchart LR
    A["1 · schema package<br/>(zod → JSON Schema → TS + Swift/Kotlin types)"]
    B["2 · daemon core<br/>workspace store · registry · work engine · message bus"]
    C["3 · MCP tool servers"]
    D["4 · session host + runtime adapters"]
    E["5 · prompt assembly"]
    F["6 · wake engine + scheduler"]
    G["7 · WS API + client SDK"]
    H["8 · desktop shell<br/>chat · board · files"]
    I["9 · studio floor (3D)"]
    J["10 · integrations · media · marketplace"]
    A-->B-->C-->D-->E-->F-->G-->H-->I
    C-.->J
```

Steps 1–7 are the product. Steps 8–9 are the experience. Step 10 is the business.
Matrix's own build clearly followed roughly this order — the daemon is far more mature and
better factored than the Swift layer, which carries a lot of near-duplicate DTOs.
