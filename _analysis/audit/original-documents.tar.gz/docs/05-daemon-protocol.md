# Daemon Protocol Specification

Transport, framing, auth, and the complete endpoint surface between `Matrix.app` and
`neo-agent`.

---

## 1. Transport

```
WebSocket   ws://127.0.0.1:7319/ws        primary, bidirectional, JSON frames
UNIX socket ~/.neo/daemon/neo.sock        control plane (start/stop/status)
HTTP        same origin                    file/attachment streaming with Range support
```

- Loopback-only unless `NEO_DAEMON_ALLOW_NON_LOOPBACK=1` (§9 of the runtime spec).
- API server idle timeout: **120 s**.
- Auth: owner lease (`ownerMode: "swift_child"`) or `NEO_OWNER_TOKEN` bearer for standalone.
- Uploads are chunked (`workspace.fs.upload.begin/chunk/commit/abort`) and land in
  `<ws>/storage/attachments/<uuid>/<sanitized-name>`.

### 1.1 Frame shape

Requests carry a method name and params; responses and server-pushed events share the same
envelope. On the Swift side every payload has a `Hub*` Codable DTO — 259 of them — which is
effectively the published schema. `HubEventCodingKeys`, `HubInboundEvent`, `HubChannelValue`
and `HubEmptyResult` are the envelope types; `HubConnectionStatus` drives the UI's
"Matrix is still connecting" states.

```mermaid
sequenceDiagram
    participant S as Matrix.app (HubService)
    participant D as neo-agent
    S->>D: connect ws://127.0.0.1:7319/ws
    D-->>S: runtime.capabilities
    S->>D: workspace.list
    D-->>S: {workspaces:[…]}
    S->>D: workspace.switch {workspaceId}
    S->>D: session.create {workspace, departmentId}
    D-->>S: HubSessionCreateResponse
    S->>D: chat.send {sessionId, content, attachments}
    loop turn
        D-->>S: task.started / task.reasoning / task.tool.start
        D-->>S: chat.delta (streaming text)
        D-->>S: task.tool.end / task.tool.update
    end
    D-->>S: chat.delta.done
    D-->>S: department.status / okr.task.changed / workspace.fs.changed
```

---

## 2. Endpoint surface (~230 methods)

Events pushed by the daemon are marked **↯**.

### 2.1 Workspace

```
workspace.list  .create  .rename  .delete  .switch  .restore
workspace.proactive                      toggle autonomy master switch
workspace.email.get  .set
```

### 2.2 Workspace filesystem (the Files module — 40 methods)

```
workspace.fs.list  .read  .write  .batch  .copy  .move  .preview  .metadata  .search
workspace.fs.history  .lineage  .summaries
workspace.fs.revision.diff  .restore  .pin  .unpin  .pins
workspace.fs.tag.add  .remove
workspace.fs.directory.pin  .unpin  .pins
workspace.fs.trash.prepare  .commit  .abort           two-phase delete
workspace.fs.upload.begin  .chunk  .commit  .abort     chunked upload
workspace.fs.access  .access.record
workspace.fs.collaboration.list  .recent  .delta  .rebuild
workspace.fs.indexing.progress ↯   workspace.fs.changed ↯
```

Two-phase trash and two-phase upload are both there so a crash never leaves a half-state.

### 2.3 Departments

```
department.list  .get  .create  .update  .delete  .rename
department.config.get  .config.update
department.skills.refresh
department.message.thread
department.activity ↯   department.status ↯   department.catalog.changed ↯
```

### 2.4 Sessions

```
session.create  .list  .attach  .detach  .close  .interrupt  .refresh
session.send  .history  .context  .cache_stats  .live
session.models.list  .set_model  .toggle_plan_mode
session.turn_failure ↯   session.turn_stream_inactivity ↯
```

### 2.5 Chat

```
chat.bootstrap  .send  .abort  .history  .search  .read_recent  .rerun
chat.queue.cancel  .clear  .resume  .retry  .steer
chat.reply_mode.get  .set
chat.endpoints  .endpoint.ack
chat.message ↯  chat.delta ↯  chat.delta.done ↯  chat.aborted ↯  chat.live_state ↯
```

`chat.queue.steer` is notable: the user can redirect a *queued* turn before it starts.

### 2.6 Tasks (streaming agent work)

```
task.list  .detail  .create  .upsert  .update  .check_in  .messages  .output  .summary
task.interrupt  .stop  .steer  .followup  .prompt  .plan
task.permission.request ↯  task.permission.respond
task.started ↯ .created ↯ .updated ↯ .completed ↯ .failed ↯ .cancelled ↯ .stopped ↯
task.delta ↯ .delta.done ↯ .reasoning ↯ .notification ↯
task.tool ↯ .tool.start ↯ .tool.update ↯ .tool.end ↯
```

### 2.7 OKR

```
okr.state             single write surface (mirrors mcp__okr__state)
okr.store.get  .update
okr_task.list  .upsert  .check_in
objective.create  .update  .state_patch  .delete
key_result.create  .update  .state_patch  .delete
okr.task.changed ↯
```

### 2.8 Cron

```
cron.list  .create  .update  .delete  .trigger  .history
cron.job.changed ↯   cron.run.status ↯
```

### 2.9 Hooks / WorkRuns

```
hook.work.list   hooks.list   hooks.update
hook.work.changed ↯
```

### 2.10 Runtimes & models

```
runtime.list  .capabilities  .install  .cancel_install  .uninstall  .progress ↯
runtime.sign_in  .sign_in.cancel  .sign_in.provide_code  .sign_out
runtime.import_user_default_auth  .set_model  .set_billing
runtime.worker_models.list  .integrations.refresh
runtime.stream.list  .stream.events ↯  .raw.event ↯  .state_changed ↯  .subscription_prompt ↯
config.models.list  .set_default  .set_enabled
config.providers.list  .get  .set  .delete  .set_active
config.providers.oauth.start  .complete  .sign_out
config.providers.openrouter.models.search
config.credentials.list  .get  .set  .delete  .set_active
config.credentials.oauth.start  .complete  .sign_out
config.test_connection
codex.service.status  .connect  .disconnect  .sign_out
codex.service.login.start  .login.cancel  .import_user_default
experimental.codex_subscription.status
```

### 2.11 Skills & memory

```
skill.list  .create  .delete  .file.write  .file.delete
memory.list
```

### 2.12 Dashboard & maintenance

```
dashboard.config.get  .config.update  .refresh.run
maintenance.config.get  .config.update  .trigger
nudge.decisions.list  nudge.periodic
```

### 2.13 Terminal

```
terminal.run
terminal.session.create  .list  .attach  .close  .input  .resize
terminal.session.output ↯  .status ↯
```

### 2.14 Integrations, channels, revenue

```
composio.installs.list  .upsert  .patch  .remove
cloudflare.accounts.list  .zones.list  .dns.records.list/.upsert/.delete
cloudflare.pages.projects.list  .workers.services.list
cloudflare.registrar.domains.check  .search
social.accounts.list  .account.connect  .account.remove
telegram.status  .configure  .connect  .sign_out  .stop  .status_changed ↯
media.image  .video  .audio
billing.activity
```

### 2.15 Sync

```
sync.status  .pull  .push  .apply  .conflicts  .conflict.resolve
```

### 2.16 Misc

```
activity.broadcast   focus.broadcast   presence.update   read.marker
user.input.delivery ↯
bench.cron.trigger   bench.mail.inject   bench.nudge.tick      (BENCH_MODE=1 only)
```

---

## 3. Event taxonomy

```mermaid
flowchart LR
    subgraph src["Sources"]
        A["Agent runtime stream"]
        B["State mutations"]
        C["Watchers"]
        D["Schedulers"]
    end
    subgraph ev["Client-visible events"]
        E1["chat.* — conversational stream"]
        E2["task.* — work stream + permissions"]
        E3["*.changed — state invalidation"]
        E4["runtime.* — install/auth/model"]
        E5["workspace.fs.* — file tree + indexing"]
        E6["department.status/activity — presence"]
    end
    A --> E1 & E2
    B --> E3
    C --> E5
    D --> E3 & E6
```

Three distinct streams matter for UI design:

1. **Conversational** (`chat.delta`) — the text the user reads.
2. **Work** (`task.tool.start/update/end`, `task.reasoning`) — what the agent is *doing*;
   this is what drives the Kanban board and the 3D office animations.
3. **Invalidation** (`*.changed`) — cheap signals that tell the client to refetch.

Keeping these separate is why Matrix can render the same turn as text, as a card, and as an
avatar walking to a whiteboard, all from one backend.

---

## 4. Client-side contract (Swift `Hub*` DTOs)

Representative groups, all Codable structs in the `Matrix` module:

| Group | DTOs |
|---|---|
| Connection | `HubService`, `HubConnectionStatus`, `HubServiceError`, `HubInboundEvent`, `HubChannelValue`, `HubEventCodingKeys`, `HubEmptyResult` |
| Chat | `HubChatBootstrapResponse`, `HubChatHistoryResponse/Item`, `HubChatMessageEvent`, `HubChatDeltaEvent`, `HubChatDeltaDoneEvent`, `HubChatAbortedEvent`, `HubChatSendResponse`, `HubChatQueueActionResponse`, `HubChatLiveState`, `HubChatSearchResponse/Item`, `HubChatContentPart` |
| Department | `HubDepartmentSummary`, `HubDepartmentProfile`, `HubDepartmentCapabilities`, `HubDepartmentCollaborationBoundary`, `HubDepartmentListResponse/Mode`, `HubDepartmentConfigResponse/UpdateResponse`, `HubDepartmentCreateResponse`, `HubDepartmentRenameResponse`, `HubDepartmentStatusEvent`, `HubDepartmentCatalogChangedEvent`, `HubDepartmentTelemetry`, `HubDepartmentMessageThread/Item/Response`, `HubDepartmentMessageAttachment`, `HubDepartmentMessageDelivery`, `HubDepartmentManualSummary*` |
| OKR | `HubOkrStoreResponse`, `HubOkrMutationResponse`, `HubOkrTaskRecord/ListResponse`, `HubOkrTaskCheckInRecord`, `HubOkrTaskCriteriaItem`, `HubOkrTaskTrigger`, `HubOkrTaskChangedEvent` |
| Sessions | `HubSessionCreateResponse`, `HubSessionListResponse`, `HubSessionSummary`, `HubSessionRefreshResponse`, `HubSessionSetModelResponse`, `HubSessionRuntimeMeta`, `HubSessionContextUsage`, `HubContextSnapshot`, `HubContextSnapshotProviderUsage` |
| Cron | `HubCronListResponse`, `HubCronJobRecord`, `HubCronRunRecord`, `HubCronHistoryResponse`, `HubCronJobChangedEvent`, `HubCronRunStatusEvent` |
| Hooks | `HubRuntimeHookRecord/ListResponse/ChangedEvent`, `HubRuntimeHookProgress`, `HubRuntimeHookRetryPolicy`, `HubRuntimeHookResultRef`, `HubRuntimeHookTaskRef`, `HubRuntimeHookWorkRunRef`, `HubRuntimeHookInputSummary` |
| Models | `HubModelListResponse`, `HubAvailableModel`, `HubModelValue`, `HubModelRouteKind`, `HubModelServiceTier`, `HubModelSetDefaultResponse`, `HubModelCatalogSourceStatus`, `HubModelPropagationResult/Failure`, `HubAgentModelConfig`, `HubOpenRouterModelSearch*` |
| Auth/creds | `HubCredentialsListResponse`, `HubCredentialGetResponse/SetResponse`, `HubCredentialModelProbeStatus`, `HubProviderDefinition`, `HubProviderStatus`, `HubCodexService*` |
| Files/memory/skills | `HubMemoryListResponse/Record/FileRecord`, `HubSkillListResponse/Record/FileRecord/CreateResponse` |
| Dashboard | `HubDashboardConfigResponse`, `HubDashboardRefreshConfig/RunResponse/Snapshot` |
| Autonomy | `HubNudgeDecisionEntry/DecisionsResponse`, `HubNudgeNextStepRefs/Sample`, `HubQueuedAutonomousHold`, `HubActiveHours` |
| Permissions | `HubPermissionRequestEvent`, `HubPermissionQueueEntry` |
| Revenue/identity | `HubBillingActivityEntry/Response`, `HubLinkWallet*`, `HubSocialAccount*`, `HubLocalUserIdentity`, `HubLegacyWorkspaceUserProfileRecord` |
| Browser | `HubMatrixBrowserSession` |
| Media | `HubCharacterAssetRegisterResponse` |
| Onboarding | `HubOnboardingBentoItem`, `HubOnboardingOpeningDispatchResponse`, `HubPrepareAcquisitionHandoverResponse`, `HubPrepareMarketplaceDepartmentHandoffResponse` |

**Recommendation for shotgun-next:** define this contract once in a schema language
(TypeBox/zod → JSON Schema → generated Swift/TS types). Matrix clearly hand-wrote both sides,
which is why there are 259 near-duplicate DTOs.
