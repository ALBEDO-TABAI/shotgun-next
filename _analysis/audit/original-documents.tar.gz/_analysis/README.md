# Raw Extraction

Evidence base for the dossier. Everything here is derived from `/Applications/Matrix.app` and
the live runtime state on this machine.

```
_analysis/
├── app-copy/Matrix.app/          verbatim copy of the installed bundle (894 MB)
├── extracted/
│   ├── neo-agent.bun             raw __BUN Mach-O section (4.8 MB)
│   ├── neo-agent.js              carved JS (12 073 lines, dense)
│   ├── neo-agent.fmt.js          ← beautified, 153 126 lines — THE DAEMON SOURCE
│   ├── neo-intelligence.bun      raw section (17.6 MB)
│   ├── neo-intelligence.js       carved JS (321 732 lines)
│   ├── neo-intelligence.fmt.js   ← beautified, 615 762 lines — THE AGENT RUNTIME
│   ├── matrix-browser-server.bun small loader section (16 KB)
│   └── mcp_tools_raw.txt         all 27 MCP tool definitions, extracted
└── swift/
    ├── type_descriptors.txt      4 918 mangled nominal type descriptors
    ├── types_demangled.txt       demangled
    ├── all_types.txt             3 756 distinct top-level Matrix types
    └── types_by_file.txt         grouped by private discriminator = SOURCE FILE (279 files)
```

## Reading the extraction

| Want | Look at |
|---|---|
| the daemon's architecture | `extracted/neo-agent.fmt.js` — **not minified**; module names, function names and full prompt text survive |
| the module map | `grep -oE 'var init_[A-Za-z0-9_]+ = __esm' neo-agent.fmt.js` → 417 modules in dependency order |
| prompts | `grep -n 'You are the' neo-agent.fmt.js`; `buildDepartmentPromptContext` at line ~129987 |
| MCP tools | `extracted/mcp_tools_raw.txt`, or `grep -n 'createSdkMcpServer' neo-agent.fmt.js` |
| the agent runtime's tools | `neo-intelligence.fmt.js` — minified identifiers, but **all strings and tool descriptions intact**; grep for prose |
| the UI structure | `swift/types_by_file.txt` — types grouped by source file |
| seed prompts & skills | `app-copy/.../Resources/neo-agent-seed/` (plain files) |
| the browser stack | `app-copy/.../Resources/matrix-browser/` (plain Node tree) |

## Reproducing

Full command sequence: [`../docs/10-build-and-packaging.md`](../docs/10-build-and-packaging.md#5--reproducing-this-teardown).

## Live runtime state (not copied here)

Read-only references used in the dossier, on this machine only:

```
~/.neo/config.json                                    workspace registry
~/.neo/workspaces/<ws>/{config,okr,dashboard}.json    real company state
~/.neo/workspaces/<ws>/departments/<id>/tasks/*.md    real Task packets
~/.neo/workspaces/<ws>/department-messages/messages.sqlite   the bus
~/.neo/daemon/status.json                             liveness
~/Library/Application Support/Matrix/agent_minds.*.json      persona state
~/Library/Preferences/com.matrixai.app.plist          UI restoration keys
```

## Caveats

- `neo-intelligence` identifiers are mangled; type names in that bundle are inferred from strings
  and call sites, not from symbols.
- Swift private discriminators group types by source *file*, but the file *names* are not
  recoverable — only their membership.
- Network protocol details beyond the bundled code (the Matrix Gateway's own API) are out of
  scope; only the client side is observable here.
