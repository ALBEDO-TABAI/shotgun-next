# D11 · Office Scene Synchronization

## App state → 3D scene

```mermaid
flowchart TB
    subgraph events["Daemon events"]
        E1["department.status / activity"]
        E2["task.tool.start / update / end"]
        E3["chat.delta"]
        E4["hook.work.changed (progress)"]
        E5["workers list / runtime state"]
        E6["department message delivery"]
    end

    subgraph model["OfficeSceneModel"]
        SIG["OfficeSceneUpdateSignature"]
        WS["OfficeWorkerSceneState<br/>+ SceneAction / ResolvedWorkerActionKind"]
        NAV["OfficeWorkerNavigation<br/>waypoints · travel mode · seat mode"]
        ANC["OfficeWorkerAnchor → ResolvedAnchor"]
        CONV["OfficeWorkerConversation / BoardroomMeetingState"]
        MIND["AgentMindService<br/>mood · energy · traits (display only)"]
    end

    subgraph gate["Signature gate"]
        G1["scene signature changed?"]
        G2["worker screen texture signature?"]
        G3["presentation panel signature?"]
        G4["department sign cache key?"]
        G5["vacant workstation cache key?"]
    end

    subgraph render["OfficeMetalRenderer"]
        P1["pipeline bundles: mesh · VRM · primitive · depth · sampler"]
        P2["passes: shadow → opaque → SSAO → TAA → bloom → exposure → composite"]
        P3["MetalFX upscale · adaptive load level"]
        CACHE["signature-keyed caches"]
    end

    subgraph overlay["SwiftUI overlays"]
        O1["OfficeProjectedPoint / OverlayProjection"]
        O2["InteractionPrompt · DetailOverlay"]
        O3["DepartmentArtifactsSpatialOverlay"]
    end

    events --> model --> gate
    gate -->|unchanged| NOOP["no GPU work"]
    gate -->|changed| render --> overlay
    MIND -.->|"idle behaviour, reactions"| WS
```

## Entity mapping

```mermaid
flowchart LR
    D["Department"] --> R["room · carpet material · corner sign · folder cluster"]
    W["Worker / running session"] --> A["VRM character at an allocated workstation"]
    O["Worker output"] --> S["live texture on its monitor"]
    AR["Department artifact"] --> F["folder object (folder-single.glb)"]
    SK["Skill"] --> B["book on skill-shelf.glb"]
    MSG["Department message"] --> FL["flight pulse between rooms"]
    LV["Live session / voice"] --> HUD["HUD · participant rows · visitor banner"]
    OBJ["Objective / dashboard"] --> PP["presentation panel in the boardroom"]
```

## Render passes

```mermaid
flowchart LR
    V1["office_mesh_shadow_vertex<br/>office_vrm_shadow_vertex<br/>office_shadow_vertex"] --> SH["shadow map"]
    SH --> OP["office_mesh_fragment<br/>office_vrm_vertex<br/>city_terrain_* · farm_grass_*"]
    OP --> AO["office_ssao_fragment"]
    AO --> TA["office_taa_fragment<br/>(office_reactive_mask_kernel)"]
    TA --> BL["office_bloom_extract_* → office_blur_*"]
    BL --> EX["office_exposure_kernel"]
    EX --> RF["office_reflection_resolve_kernel"]
    RF --> CO["office_composite_fragment"]
    BG["office_environment_background_fragment<br/>office_baked_sky_fragment"] --> CO
```

## Adaptive degradation

```mermaid
flowchart TD
    M["frame timings + OfficeMetalRendererGPUPressure"] --> E["RuntimePressureEvaluation"]
    E --> Q{"pressure"}
    Q -->|low| F["full quality tier · full city · MetalFX off/spatial"]
    Q -->|medium| G["reduce adaptiveLoadLevel<br/>fewer city buildings/trees<br/>MetalFX temporal"]
    Q -->|high| H["static environment cache only<br/>drop marine traffic, grass instancing<br/>lower sky quality"]
    F & G & H --> R["rebuild only the affected signature-keyed caches"]
```
