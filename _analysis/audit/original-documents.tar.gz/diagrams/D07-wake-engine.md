# D07 · Wake Engine

## Full pipeline

```mermaid
flowchart TB
    subgraph src["Sources"]
        U["user chat"]; DM["department message"]; CR["cron tick"]
        HK["hook (async fact)"]; ND["nudge tick"]; SY["system<br/>onboarding · handover · import · maintenance · internal"]
    end

    U --> IMM; SY --> IMM
    DM & CR & HK & ND --> COAL

    IMM["dispatchWakeNow"]
    COAL{{"shouldCoalesceWake?<br/>window &gt; 0 AND reason ∈<br/>{cron,hook,nudge,department_message}"}}
    COAL -->|no| IMM
    COAL -->|yes| BUF["buffer[workspaceId/deptId]<br/>entries: {trigger, resolve, reject}"]
    BUF -->|"timer fires"| FLUSH{"entries == 1 ?"}
    FLUSH -->|yes| IMM
    FLUSH -->|no| CO["reason = coalesced<br/>signals[]"] --> IMM

    IMM --> MUTEX["fireMutexByHost<br/>prev.then(() =&gt; doDispatch)"]
    MUTEX --> DIR["autonomy.directives(deptRoot)<br/>throws → render with []"]
    DIR --> POL["applyCurrentNudgePolicy"]
    POL -->|"all nudge signals denied"| DENY["throw NudgePolicyDeniedError"]
    POL --> BUSY{"isDepartmentNudgeBusy?"}
    BUSY -->|yes| BACK["set nudgeBackoffUntil"]
    BUSY -->|no| GATE{"periodic? → activity gate"}
    GATE -->|"nothing moved"| SKIP["log decision, skip"]
    GATE -->|ok| ENV["render wake envelope<br/>(coalesced = one action-oriented briefing)"]
    ENV --> TURN["SessionHost turn"]
    TURN --> AUD[".neo/wake-runs/&lt;reason&gt;/"]
    SKIP --> DEC[".neo/nudge-decisions/"]
    BACK --> DEC
```

## Lane policy

```mermaid
flowchart TD
    W{"workspaceConfig.proactive === true ?"}
    W -->|no| D0["DISABLED<br/>{postTurn:false, periodic:false, proactiveOn:false}"]
    W -->|yes| L{"department lifecycle"}
    L -->|"retired / merged"| D0
    L -->|active| P{"is primary?"}
    P -->|yes| PR["PRIMARY<br/>{postTurn:true, periodic:true, proactiveOn:true}"]
    P -->|no| DP["DEPARTMENT<br/>{postTurn:true, periodic:false, proactiveOn:false}"]
```

## Next-step reason order (shared with the dashboard)

```mermaid
flowchart TD
    R1["1 · due_time_trigger<br/>execute next action, attach proof, next Task"]
    R2["2 · blocked_task<br/>remove / route / report the smallest real blocker"]
    R3["3 · proof_check_in_pending<br/>check proof vs criteria, update KR, decide learning"]
    R4["4 · active_task<br/>advance until proof, check-in, or blocker"]
    R5["5 · active_key_result_missing_task<br/>create the smallest movable proof-bearing Task"]
    R6["6 · active_objective_missing_first_key_result<br/>create the first KR, then a Task"]
    R1 --> R2 --> R3 --> R4 --> R5 --> R6
    NOTE["each ref carries owner · route · stop condition<br/>act through that route until the stop condition holds"]
    R6 -.- NOTE
```
