# shotgun-next · The Build

The recreation plan: Matrix's machine, pointed at creative production.

| # | Document | What it settles |
|---|---|---|
| 00 | [Brief](00-brief.md) | what the product is, what changes from Matrix, the default ensemble |
| 01 | [Target architecture](01-target-architecture.md) | processes, filesystem, transport, layer rules |
| 02 | [Role system](02-role-system.md) | seats, profiles, ownership policy, emergent roles |
| 03 | [Data model](03-data-model.md) | every entity, every enum, the message schema |
| 04 | [Tool surface](04-tool-surface.md) | every MCP tool and built-in a role gets |
| 05 | [Prompt system](05-prompt-system.md) | context layers, the cache contract, maintenance prompts |
| 06 | [UI spec](06-ui-spec.md) | shell, surfaces, the review queue |
| 07 | [Studio floor](07-studio-floor.md) | the 3D layer — what to build, what to buy |
| 08 | [Build plan](08-build-plan.md) | six phases, ~15 weeks, risks, test strategy |
| 09 | [Decisions](09-decisions.md) | 15 explicit calls and the open questions |

Diagram: [D15 · shotgun-next target](../diagrams/D15-shotgun-target.md)

---

## The three ideas that carry the product

**1 · Ownership is a data structure, not a personality.**
Every seat carries `collaborationBoundary: { keepLocal, handoffToRole, createChildRole }`.
The Director is structurally pushed to route rather than to make. Matrix spends hundreds of
prompt words on this because it is the difference between a team and a costume party.

**2 · Nothing is done without a verdict.**
Acceptance criteria are the gate; deliverable refs satisfy them; only a Review writes terminal
states; and a maker cannot accept its own work. Placeholders are blockers, never deliverables.

**3 · Your taste becomes durable state.**
Every review must decide what the studio learns. A correction becomes a **style lock** in the
same turn, and every later generation inherits it. This is why the studio feels like it learns
instead of resetting.

---

## What to build first

```
Week 1     schema package — one source of truth for both sides
Weeks 2-4  daemon + state engines — provable with no LLM in the loop
Weeks 5-7  sessions + prompt + the two core tools  ← the risky phase
Weeks 8-11 autonomy + generation + client
Weeks 12+  maintenance, board, integrations, the floor
```

The exit test for week 7 is the whole bet:

> You brief a launch film in one sentence. The Director shapes it, creates a seat that didn't
> exist, dispatches, receives a delivery, and the Critic files a verdict — end to end, once.
