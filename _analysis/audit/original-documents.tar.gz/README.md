# Matrix — Complete Teardown & Reconstruction Spec

Reverse-engineering dossier for **Matrix.app 1.0.6 (build 148)** — a macOS "Agent Company"
desktop application — produced as the technical foundation for **shotgun-next**, a
multi-agent collaboration studio where agents work together in professional roles.

Source of truth: `/Applications/Matrix.app`, copied verbatim to `_analysis/app-copy/`,
plus the live runtime state at `~/.neo` and `~/Library/Application Support/Matrix`.

---

## What Matrix actually is

A **native Swift/SwiftUI macOS app** that acts as the cockpit for a **local agent company**.
The company itself runs as a **local Bun-compiled TypeScript daemon** (`neo-agent`, aka the
*harness*) which owns a filesystem-backed workspace and spawns one long-lived **agent session
per department**. Each department session is an instance of `neo-intelligence` — a
Claude-Code-derived agent runtime rebranded as **Neo** — or optionally an external
`claude_code` / `codex` binary. Departments coordinate through a SQLite message bus, share an
OKR state machine, own memory and skills, and are woken by a multi-lane autonomy scheduler.

Matrix renders all of this three ways: a conventional chat/sidebar app, a Kanban "Work" board,
and a **real-time 3D office** (Metal renderer, VRM avatars, San Francisco city environment)
in which each department is a room and each worker is an animated character at a desk.

```
You ──► Matrix.app (SwiftUI + Metal)
          │  WebSocket 127.0.0.1:7319/ws
          ▼
        neo-agent  ── the harness daemon (Bun/TS)
          │
          ├── department session × N ──► neo-intelligence | claude | codex
          ├── MCP servers (matrix, okr, cron, files, media, receivable, browser, packs)
          ├── matrix-browser (Playwright + patched Chromium "CloakBrowser")
          └── ~/.neo/workspaces/<ws>/…  ── the company on disk
```

---

## How to read this dossier

| Path | Contents |
|---|---|
| [`00-EXECUTIVE-SUMMARY.md`](00-EXECUTIVE-SUMMARY.md) | The 10-minute version + the single big architecture diagram |
| [`docs/`](docs/) | Cross-cutting specifications: runtime, process topology, data model, protocol, prompts, autonomy, UI, 3D, security, packaging |
| [`modules/`](modules/) | One specification per module (28 modules), each with its own diagrams |
| [`tools/`](tools/) | One specification per tool surface — every MCP tool, every built-in agent tool, every managed skill |
| [`diagrams/`](diagrams/) | Standalone Mermaid diagrams, indexed and reusable |
| [`shotgun/`](shotgun/) | **The build plan** — how to recreate this as a multi-agent studio |
| [`_analysis/`](_analysis/) | Raw extraction: app copy, unpacked Bun bundles, demangled Swift type graph |

Start at `00-EXECUTIVE-SUMMARY.md`, then `docs/02-runtime-architecture.md`,
then `shotgun/00-brief.md`.

---

## Evidence base

Everything in this dossier is derived from artifacts on this machine, not from documentation.

| Artifact | How it was obtained | Yield |
|---|---|---|
| `Contents/MacOS/Matrix` (166 MB, Mach-O arm64) | `nm` + `swift-demangle` on 379 235 mangled symbols | **3 756 Swift types across 279 source files** — the complete UI/type graph |
| `Resources/neo-agent` (65 MB) | Bun `__BUN` Mach-O section extracted, `deno fmt` | **153 126 lines of readable TypeScript** — the entire daemon, 417 modules |
| `Resources/neo-intelligence` (78 MB) | same | **615 762 lines** — the agent runtime (minified identifiers, intact strings/prompts) |
| `Resources/matrix-browser/` | plain Node/Playwright tree + Rust supervisor | Browser automation stack + Chromium 145 fork |
| `Resources/neo-agent-seed/` | plain files | Seed prompts, workspace schema, 11 managed skill templates, integration packs |
| `~/.neo/` (live) | filesystem | Real workspaces, departments, task packets, SQLite message bus, traces |
| `en.lproj/Localizable.strings` | `plutil` | 5 768 UI strings incl. the vendor's own architecture tutorial |

Extraction commands are reproduced in [`docs/10-build-and-packaging.md`](docs/10-build-and-packaging.md#5--reproducing-this-teardown).

---

## Version pinned

```
Matrix            1.0.6 (148)   built 2026-08-20T13:35:56Z   macOS 14.6+, arm64
neo-agent         0.1.60        sha 76894dbbb
neo-intelligence  0.1.60        sha 76894dbbb
matrix-browser    0.1.0         Chromium 145.0.7632.109
bundled runtimes  claude-code 2.1.126 · codex 0.144.4
bundle id         com.matrixai.app      URL scheme  matrix://
```
