# M30 · Voice & Presence

**Source:** `LiveKitWebRTC.framework`, `RustLiveKitUniFFI.framework`, `ElevenLabs.bundle`,
`RealtimeVoiceClient`, `ElevenLabsVoiceClient`, `VoiceCallSession/Phase`,
`SpeechRecognitionService`, `TextToSpeechService`, `Office{Live,Voice}*`,
`presence.update` / `focus.broadcast` / `activity.broadcast`

---

## Purpose

Talk to the company, and let other people visit it.

## Configuration

```
Info.plist:
  MATRIX_VOICE_PROVIDER          = "elevenlabs"
  MATRIX_ELEVENLABS_AGENT_ID     = ""        (blank in this build)
  MATRIX_ELEVENLABS_ENVIRONMENT  = ""
Entitlement: com.apple.security.device.audio-input
TCC: NSMicrophoneUsageDescription, NSSpeechRecognitionUsageDescription
```

## Two voice paths

```mermaid
flowchart TB
    subgraph dictate["Dictation (composer)"]
        M1["mic"] --> SR["SpeechRecognitionService"] --> TXT["text into ChatComposer"]
        ORB["ComposerVoiceLiquidOrb + VoiceStatusGlowDot"]
    end
    subgraph convo["Conversational (office)"]
        M2["mic"] --> RVC["RealtimeVoiceClient / ElevenLabsVoiceClient"]
        RVC --> VCS["VoiceCallSession (VoiceCallPhase)"]
        VCS --> TTS["TextToSpeechService"] --> SPK["speaker"]
        VCS --> HUD["OfficeVoiceSceneHUD + VoiceHUDButton"]
    end
```

Path 1 is dictation into the composer — cheap, always available, with a liquid-orb visualisation.
Path 2 is a real-time conversation with a department while you are standing in its room.

## Multiplayer

LiveKit provides rooms; the Swift SDK is backed by a Rust core over UniFFI.

```
OfficeLivePanelView · OfficeLiveParticipantRow · OfficeLiveStatusPill
OfficeLiveVisitorSceneBanner / SceneContext · OfficeVisitorSnapshot
OfficeLivePlayDeck / PlayAction / PlayActionLabel / InteractionKind
OfficeLocalLiveInteraction / LocalInteractionKind
HubMatrixBrowserSession, HubService.broadcastFocus/broadcastActivity
```

So a second person can join your office, be visible as an avatar, and participate.

## Presence protocol

```
presence.update        who is here
focus.broadcast        which department the user is looking at
activity.broadcast     lastActivityMs — idle detection
read.marker            read position in a conversation
```

`focus` feeds back into the autonomy engine (bias toward what the user is watching) and into the
3D scene (camera hints, avatar attention).

## Reuse in shotgun-next

**Keep dictation** — high value, low cost, and creatives talk more than they type.

**Keep conversational voice for review sessions** — "walk me through the cut" is a natural
studio interaction, and `VoiceCallPhase` + a scene HUD is most of the work.

**Defer multiplayer** until there is a second user. But keep `focus.broadcast` from day one: it
is cheap, it improves autonomy targeting, and it is the hook multiplayer later plugs into.
