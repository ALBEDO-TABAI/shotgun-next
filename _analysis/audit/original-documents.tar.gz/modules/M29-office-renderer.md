# M29 · Office Renderer

**Source:** 264 `Office*` Swift types, `default.metallib` (28 shader entry points), GLB/USDZ/HDR
assets, `sf_downtown_osm_environment.json`, `office_post_processing.json`

Full detail in [docs/08-office-3d-world.md](../docs/08-office-3d-world.md). This page is the
module-level contract.

---

## Purpose

Render the company as a place, and keep it synchronized with real agent state at 60 fps.

## Layer contract

```mermaid
flowchart TB
    subgraph app["App state"]
        EV["daemon events:<br/>department.status · task.tool.* · chat.delta · hook progress"]
    end
    subgraph model["OfficeSceneModel"]
        SIG["OfficeSceneUpdateSignature"]
        SYNC["OfficeSceneSyncState"]
        WS["OfficeWorkerSceneState / SceneAction / Navigation / Anchor"]
    end
    subgraph rend["OfficeMetalRenderer"]
        PL["pipeline bundles"]
        CACHE["signature-keyed caches"]
        FX["SSAO · TAA · bloom · exposure · reflections · MetalFX"]
    end
    subgraph ui["SwiftUI overlays"]
        PROJ["OfficeProjectedPoint / OverlayProjection"]
        PROMPT["InteractionPrompt · DetailOverlay"]
    end
    app --> model --> rend --> ui
```

**The signature gate is the whole performance story.** `OfficeSceneUpdateSignature` is computed
from app state; if it hasn't changed, no GPU work is enqueued. Sub-signatures do the same at
finer grain:

```
OfficeWorkerScreenTextureSignature        worker monitor content
OfficePresentationPanelTextureSignature   presentation panel content
OfficeDepartmentSignCacheKey              department sign text
OfficeVacantWorkstationCacheKey/SlotKey/AgentKey   desk allocation
OfficeStaticSceneCacheKey                 static environment
OfficeCityResourceCacheKey                city geometry
OfficePixelTextMaskCacheKey               in-world pixel text
OfficeVoiceSceneSignature                 voice HUD state
```

## Adaptive load

```
OfficeRenderQualityProfile / Tier
OfficeAdaptiveSceneLoadProfile → adaptiveLoadLevel: Int
OfficeMetalRendererGPUPressure → RuntimePressureEvaluation
OfficeMetalFXMode / Upscaler
```

Under pressure the renderer reduces **scene content**, not just resolution — `adaptiveLoadLevel`
is a parameter to the city generator.

## Entity mapping

| Domain entity | Scene entity |
|---|---|
| Department | a room, a carpet material, a corner sign, a folder cluster |
| Worker (running session/agent) | a VRM character at an allocated workstation |
| Worker output | a texture on its monitor |
| Department artifact | a folder object (`folder-single.glb`) |
| Skill | a book on `skill-shelf.glb` |
| Department message | a "flight" pulse between rooms |
| Live session / voice | HUD + participant rows + visitor banner |
| Objective/dashboard | a presentation panel in the boardroom |

## Behaviour system

```
OfficeWorkerSceneActionKind → ResolvedWorkerActionKind
OfficeWorkerNavigation (Waypoint, TravelMode, SeatMode) → ResolvedNavigation
OfficeWorkerConversation / ConversationFocus / ConversationSnapshot
OfficeBoardroomMeetingState
OfficeAvatarReactionKind / Request / Sound / ClickState
OfficeFirstPersonState / CollisionBlocker / PoolArea
AgentMindService / AgentMindState / AgentPersonality (mood, energy, traits)
```

Persona state (`agent_minds.<ws>.json`) drives idle behaviour and reactions and **never reaches
the model**. That separation is important: display persona is free, prompt persona is expensive.

## Cost / substitution

| Sub-layer | Build or buy |
|---|---|
| VRM parsing + skinning | **buy** — three-vrm, or an engine |
| Renderer + post-FX | **buy** — R3F / Godot / RealityKit |
| City generation | **skip** — a stylised abstract set suits a studio better |
| Anchors / desk allocation | **build** — product logic |
| Worker behaviour state machine | **build** — product logic |
| Live content as texture | **build** — this is the magic |
| Signature gate | **build** — 100 lines, huge payoff |

## Reuse in shotgun-next

Build a **studio floor**, not an office tower: a small stylised space with a desk per role, a
review wall where deliverables hang, a reference board, and a table for critique rounds.

Keep from Matrix: the signature gate, the entity mapping table, live content as texture, 2D
overlay projection from 3D anchors, and persona-for-display separated from persona-for-prompt.
