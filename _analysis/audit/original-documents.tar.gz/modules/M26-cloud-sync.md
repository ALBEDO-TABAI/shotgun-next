# M26 · Cloud Sync

**Source modules:** `apply`, `pull`, `push`, `resolve`, `conflicts`, `conflict_store`,
`department_message_snapshot`, `okr_snapshot`, `task_snapshot`, `workspace_config_snapshot`,
`revision_retention`, `content_store`

---

## Purpose

Replicate a workspace across devices with explicit, resolvable conflicts.

## Model

```mermaid
flowchart LR
    L["Local workspace"] -->|"push"| R["Remote"]
    R -->|"pull"| S["Snapshots:<br/>workspace_config · okr · task ·<br/>department_message · content"]
    S --> AP["apply"]
    AP --> C{"conflict?"}
    C -->|no| L
    C -->|yes| CS["conflict_store"]
    CS --> UI["WorkspaceCollaborationRebuildSheet"]
    UI -->|"sync.conflict.resolve"| RES["resolve"]
    RES --> L
```

Endpoints: `sync.status`, `sync.pull`, `sync.push`, `sync.apply`, `sync.conflicts`,
`sync.conflict.resolve`.

## Per-domain snapshots

Sync is **not** a file-tree diff. Each domain has a snapshot module that knows its own identity
and merge semantics:

| Snapshot | Identity | Merge behaviour |
|---|---|---|
| `workspace_config_snapshot` | departments by id | field-level |
| `okr_snapshot` | objectiveId / keyResultId | field-level, append-only proof arrays |
| `task_snapshot` | taskId | check-ins are append-only |
| `department_message_snapshot` | message id + `dedupe_key` | idempotent insert |
| content / revisions | content hash | immutable, retention-governed |

This is why conflicts are meaningful: "both devices edited KR-3's `nextAction`" is resolvable;
"both devices changed `okr.json`" is not.

Append-only structures (check-ins, proof refs, messages) merge without conflict by construction.
That is the design lever — **make the high-frequency writes append-only and most conflicts
disappear.**

## UI

`WorkspaceCloudSyncPane`, `WorkspaceCloudSyncAction`, `WorkspaceCloudSyncError`,
`WorkspaceCollaborationRebuildSheet(+Content/Footer)`,
`WorkspaceCollaborationMaintenanceSection/Header/Actions`.

Degrades honestly: *"Cloud sync is disabled in the connected daemon."*

Related: portable workspace files — *"Saved chats for portable workspace files"* — and
`zip_import` as a marketplace source, so a workspace can move as an archive without the cloud.

## Reuse in shotgun-next

Copy the **per-domain snapshot** approach and the append-only bias. Do not build a generic file
sync.

Priority for a studio: productions are large (media). Sync **state** (briefs, milestones, work
items, reviews, decisions) eagerly and **assets** lazily with explicit pinning, or the first real
production will saturate the user's connection.
